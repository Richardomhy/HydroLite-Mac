# HydroLite Studio Demo Summary

- App: `HydroLite Studio 0.6.0-beta`
- Project: `/Users/minghenyu/Documents/hydrolite 模型/projects/demo_project`
- Generated at: `2026-06-17T15:42:52.616718+00:00`
- Marked complete: `0/12`
- Steps with all success files present: `12/12`

## Recommended Routes

- Route A: 在线快速体验，按页面浏览已有结果，不强制认证 GEE/SWMM/OpenHydroNet。
- Route B: 本地完整演示，运行项目校验、批量计算、SWMM 隔离求解器和 GEE 摘要。
- Route C: 工程交付演示，重点展示项目向导、结果对比、报告导出和项目包。

## Step Checklist

| Step | Page | Marked | Files | Status |
| --- | --- | --- | --- | --- |
| 认识 HydroLite Studio | 项目首页 | False | 1/1 | passed |
| 加载 demo_project | 项目首页 | False | 4/4 | passed |
| 校验项目 | 数据与校验 | False | 2/2 | passed |
| 运行 demo_gee 情景 | 情景运行 | False | 3/3 | passed |
| 批量运行项目 | 情景运行 | False | 1/1 | passed |
| 查看 GEE 数据中心 | GEE 数据中心 | False | 2/2 | passed |
| 查看 SWMM 联动结果 | SWMM 联动 | False | 3/3 | passed |
| 查看 OpenHydroNet AI 输入包 | OpenHydroNet AI 输入 | False | 2/2 | passed |
| 查看结果对比 | 结果对比 | False | 3/3 | passed |
| 生成 Word/HTML/Markdown 报告 | 报告与导出 | False | 4/4 | passed |
| 导出项目包 | 报告与导出 | False | 1/1 | passed |
| 理解在线版与本地版差异 | 教程与 Demo | False | 1/1 | passed |

## Notes

- Demo progress only records tutorial completion state and does not delete model outputs.
- Cloud deployments can display existing outputs even when optional local backends are unavailable.
- For full GEE/SWMM/OpenHydroNet workflows, use a local environment with the required credentials and solvers.
