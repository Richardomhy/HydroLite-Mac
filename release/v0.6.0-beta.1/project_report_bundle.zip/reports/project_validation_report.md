# Project Validation Report

Project: `Demo HydroLite Project`
Project directory: `/Users/minghenyu/Documents/hydrolite 模型/projects/demo_project`
Fatal case errors: `0`
Case warnings: `14`
Case validation workbook: `/Users/minghenyu/Documents/hydrolite 模型/projects/demo_project/output/validation/validation_summary.xlsx`
