# Project Report PDF Unavailable

HydroLite generated Markdown, Word, and HTML reports, but PDF rendering is unavailable in this environment.

Requested PDF path: `<PROJECT_ROOT>/projects/demo_project/reports/project_report.pdf`
HTML report path: `<PROJECT_ROOT>/projects/demo_project/reports/project_report.html`
Reason: `No module named 'weasyprint'`

Install a supported PDF backend such as WeasyPrint to enable direct PDF export.
