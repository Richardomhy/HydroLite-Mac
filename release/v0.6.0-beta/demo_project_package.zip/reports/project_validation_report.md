# Project Validation Report

Project: `Demo HydroLite Project`
Project directory: `<PROJECT_ROOT>/projects/demo_project`
Fatal case errors: `0`
Case warnings: `14`
Case validation workbook: `<PROJECT_ROOT>/projects/demo_project/output/validation/validation_summary.xlsx`
