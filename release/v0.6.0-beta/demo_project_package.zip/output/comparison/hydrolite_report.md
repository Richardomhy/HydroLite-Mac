# HydroLite-Mac 情景对比自动报告

## 项目概况

本报告由 `python -m hydrolite compare output/` 自动生成，用于汇总 HydroLite 水文结果、Muskingum 汇流结果、水量平衡结果、SWMM 结果和 HydroLite-SWMM coupling 状态。

## 情景列表

| case_name | run_status | has_hydrolite_result | has_water_balance | has_swmm | has_coupling | notes |
| --- | --- | --- | --- | --- | --- | --- |
| demo | success | True | True | False | False | 3 expected outputs missing |
| demo_gee | success | True | True | False | False | 3 expected outputs missing |
| demo_swmm | success | True | True | True | True |  |

## HydroLite 水文结果对比

| case_name | peak_flow | peak_time | total_runoff_volume_m3 |
| --- | --- | --- | --- |
| demo | 9.440 | 2026-06-01 11:00:00 | 228120.210 |
| demo_gee | 1.378 | 2024-06-21 | 809526.382 |
| demo_swmm | 9.440 | 2026-06-01 11:00:00 | 228120.210 |

## 水量平衡对比

| case_name | max_subbasin_balance_error_percent | outlet_balance_error_percent |
| --- | --- | --- |
| demo | 0.000 | -0.296 |
| demo_gee | 0.000 | 0.000 |
| demo_swmm | 0.000 | -0.296 |

## SWMM 结果对比

| case_name | swmm_status | backend_used | max_node_depth | max_link_flow | total_flooding_volume | total_outflow_volume |
| --- | --- | --- | --- | --- | --- | --- |
| demo |  |  | NA | NA | NA | NA |
| demo_gee |  |  | NA | NA | NA | NA |
| demo_swmm | success | external_solver:pyswmm | 0.608 | 0.064 | 0.000 | 226.450 |

## HydroLite-SWMM coupling 状态

| case_name | coupling_enabled | coupling_status | target_node | inflow_name | timeseries_points | max_flow | total_inflow_volume_m3 |
| --- | --- | --- | --- | --- | --- | --- | --- |
| demo |  |  |  |  | NA | NA | NA |
| demo_gee |  |  |  |  | NA | NA | NA |
| demo_swmm | True | success | J1 | HYDROLITE_INFLOW | 26.000 | 9.440 | 227956.625 |

## 模型评估摘要

| case_name | NSE | RMSE | MAE | PBIAS | R2 | KGE | n_pairs |
| --- | --- | --- | --- | --- | --- | --- | --- |
| demo | NA | NA | NA | NA | NA | NA | NA |
| demo_gee | 0.997 | 0.025 | 0.015 | -0.641 | 0.997 | 0.990 | 32.000 |
| demo_swmm | NA | NA | NA | NA | NA | NA | NA |

## 主要结论自动摘要

- 峰值流量最大的情景为 `demo`，峰值流量 9.440 m3/s。
- 总径流量最大的情景为 `demo_gee`，总量 809526.382 m3。
- 水量平衡误差最大的情景为 `demo`，出口误差 -0.296%。
- SWMM 最大节点水深对应情景为 `demo_swmm`，水深 0.608。
- SWMM 最大管道流量对应情景为 `demo_swmm`，流量 0.064。
- 模型评估中 NSE 最高的情景为 `demo_gee`，NSE 0.997。
- 所有情景运行成功。

## 文件清单

- `scenario_comparison.xlsx`: `<PROJECT_ROOT>/projects/demo_project/output/comparison/scenario_comparison.xlsx`
- `scenario_comparison.csv`: `<PROJECT_ROOT>/projects/demo_project/output/comparison/scenario_comparison.csv`
- `peak_flow_comparison.png`: `<PROJECT_ROOT>/projects/demo_project/output/comparison/peak_flow_comparison.png`
- `volume_comparison.png`: `<PROJECT_ROOT>/projects/demo_project/output/comparison/volume_comparison.png`
- `water_balance_comparison.png`: `<PROJECT_ROOT>/projects/demo_project/output/comparison/water_balance_comparison.png`
- `swmm_kpi_comparison.png`: `<PROJECT_ROOT>/projects/demo_project/output/comparison/swmm_kpi_comparison.png`
- `hydrolite_report.md`: `<PROJECT_ROOT>/projects/demo_project/output/comparison/hydrolite_report.md`
